const express = require('express');
const router = express.Router();
const { fetchColumnRawValues } = require('../controllers/salescontroller');

router.get('/column-values', fetchColumnRawValues);

module.exports = router;
