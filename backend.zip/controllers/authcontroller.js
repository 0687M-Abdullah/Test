const jwt = require('jsonwebtoken');
const { findUserByCredentials } = require('../models/usermodel');

const login = async (req, res) => {
  const { username, password } = req.body;

  try {
    const user = await findUserByCredentials(username, password);
    if (user) {
      const token = jwt.sign(
        {
          id: user.login_id,
          username: user.username,
          role: user.role
        },
        process.env.JWT_SECRET,
        { expiresIn: '2h' }
      );
      res.status(200).json({ success: true, message: 'Login successful', token });
    } else {
      res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = { login };
