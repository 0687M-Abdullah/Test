const { poolPromise } = require('../config/db');

// Whitelisted columns to prevent SQL injection
const allowedColumns = [
  "Yarn_Inv_No", "Yarn_Inv_Date", "Cotton_QualityDes", "Yarn_PartyID",
  "Yarn_BrokerID", "PartyName", "Payment_Date", "Remarks", "Payment_Mod",
  "Cotton_GL", "P_Add", "P_CIty", "Broker_Name", "Yarn_Entry_No", "Yarn_QualityID",
  "Yarn_Bags", "Yarn_Wt_Kgs", "Store_No", "Yarn_Rate", "Yarn_Amount",
  "Yarn_GST_Rate", "Yarn_GST_Amount", "Yarn_Comm_Rate", "Yarn_COmm_Amount",
  "Yarn_GST_Input", "Expr1", "Stock_No", "Stock_Type", "Stock_Rate", "Temp_wtles",
  "Rate_LHR", "Rate_FSD", "Party", "Menu", "Discount", "Sub_Party",
  "Cotton_QualityID", "Due_Date", "Sub_ParyID", "Contract_M", "Cotton_CBR",
  "Sales_Person", "Builty_Amount"
];

const fetchColumnRawValues = async (req, res) => {
  try {
    const column = req.query.column;

    if (!column || !allowedColumns.includes(column)) {
      return res.status(400).json({ message: 'Invalid or missing column name' });
    }

    const pool = await poolPromise;

    const result = await pool.request().query(`
      SELECT DISTINCT [${column}] FROM VW_SalesDetail
    `);

    // Use dynamic access instead of row.value
    const values = result.recordset.map(row => row[column]);

    res.status(200).json(values);
  } catch (err) {
    console.error('Error fetching raw column values:', err);
    res.status(500).json({ message: 'Failed to fetch column values' });
  }
};


module.exports = { fetchColumnRawValues };
