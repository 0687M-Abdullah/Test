const { sql, poolPromise } = require('../config/db');

async function findUserByCredentials(username, password) {
  const pool = await poolPromise;
  const result = await pool
    .request()
    .input('username', sql.VarChar, username)
    .input('password', sql.VarChar, password)
    // .query('SELECT * FROM login WHERE username = @username AND password = @password');
    .query('SELECT * FROM Logins WHERE Login_Name = @username AND Password = @password');
  return result.recordset[0];
}

module.exports = {
  findUserByCredentials
};
